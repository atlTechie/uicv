<?php wp_footer(); ?>

<footer class="fixed-bottom bg-light py-3"><small class="d-block text-center">Copyright &copy; 2021. Ewright.me</small></footer>
